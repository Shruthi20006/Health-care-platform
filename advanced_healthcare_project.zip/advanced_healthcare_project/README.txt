ADVANCED HEALTHCARE PROJECT - RUN GUIDE

1. Open terminal in this project folder.
2. Install requirements:
   pip install -r requirements.txt

3. Run the app:
   python app.py

4. Open browser:
   http://127.0.0.1:5000

MAIN FEATURES ADDED:
- Secure register/login using password hashing
- Session-based dashboard protection
- Multi-symptom analysis with risk level
- Emergency alert detection
- Doctor recommendation from database
- Appointment booking with booking ID
- Payment record with transaction ID
- Patient dashboard with history page
- Modern responsive UI
