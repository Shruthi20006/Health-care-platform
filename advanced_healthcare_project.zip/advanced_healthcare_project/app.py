from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-production"
DATABASE = "healthcare.db"


# -----------------------------
# Database helpers
# -----------------------------
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            age INTEGER,
            gender TEXT,
            password_hash TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            specialization TEXT NOT NULL,
            hospital TEXT NOT NULL,
            fee INTEGER NOT NULL,
            experience INTEGER NOT NULL,
            available_days TEXT NOT NULL,
            available_time TEXT NOT NULL
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            doctor_id INTEGER NOT NULL,
            symptoms TEXT,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            status TEXT DEFAULT 'Booked',
            booking_code TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(doctor_id) REFERENCES doctors(id)
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            appointment_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            payment_status TEXT DEFAULT 'Pending',
            transaction_id TEXT,
            payment_date TEXT,
            FOREIGN KEY(appointment_id) REFERENCES appointments(id)
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS symptom_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            symptoms TEXT NOT NULL,
            duration TEXT,
            severity TEXT,
            predicted_condition TEXT,
            recommended_specialization TEXT,
            risk_level TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """
    )

    cur.execute("SELECT COUNT(*) AS total FROM doctors")
    if cur.fetchone()["total"] == 0:
        doctors = [
            ("Dr. Arjun Kumar", "General Physician", "PSG Hospitals", 300, 12, "Mon-Sat", "09:00 AM - 01:00 PM"),
            ("Dr. Nivetha Rao", "Pulmonologist", "Sri Ramakrishna Hospital", 450, 10, "Mon-Fri", "10:00 AM - 04:00 PM"),
            ("Dr. Vikram S", "Cardiologist", "GKNM Hospital", 600, 15, "Tue-Sat", "11:00 AM - 05:00 PM"),
            ("Dr. Swetha M", "Neurologist", "KMCH", 650, 11, "Mon-Fri", "02:00 PM - 06:00 PM"),
            ("Dr. Hari Prasad", "Gastroenterologist", "GEM Hospital", 500, 14, "Mon-Sat", "09:30 AM - 01:30 PM"),
            ("Dr. Meena Lakshmi", "Dermatologist", "KG Hospital", 350, 9, "Mon-Sat", "10:00 AM - 01:00 PM"),
            ("Dr. Sarath Babu", "Orthopedic", "Kongunad Hospital", 400, 13, "Mon-Sat", "05:00 PM - 08:00 PM"),
            ("Dr. Priya Anand", "ENT Specialist", "PSG Hospitals", 350, 8, "Mon-Fri", "09:00 AM - 12:00 PM"),
            ("Dr. Kavitha Raman", "Endocrinologist", "Sri Ramakrishna Hospital", 500, 10, "Wed-Sat", "03:00 PM - 07:00 PM"),
            ("Dr. Anoop Varma", "Ophthalmologist", "Aravind Eye Hospital", 300, 16, "Mon-Sat", "08:30 AM - 12:30 PM"),
        ]
        cur.executemany(
            """
            INSERT INTO doctors (name, specialization, hospital, fee, experience, available_days, available_time)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            doctors,
        )

    conn.commit()
    conn.close()


# -----------------------------
# Auth helpers
# -----------------------------
def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return func(*args, **kwargs)

    return wrapper


@app.context_processor
def inject_user():
    return {"current_user_name": session.get("user_name")}


# -----------------------------
# Symptom intelligence
# -----------------------------
SYMPTOM_RULES = {
    "fever": {"condition": "Flu / Viral Infection", "specialization": "General Physician", "risk": "Medium"},
    "cough": {"condition": "Cold / Respiratory Infection", "specialization": "Pulmonologist", "risk": "Low"},
    "shortness of breath": {"condition": "Respiratory Distress", "specialization": "Pulmonologist", "risk": "High"},
    "chest pain": {"condition": "Possible Cardiac Concern", "specialization": "Cardiologist", "risk": "High"},
    "headache": {"condition": "Migraine / Stress Headache", "specialization": "Neurologist", "risk": "Low"},
    "dizziness": {"condition": "Vertigo / BP Variation", "specialization": "Neurologist", "risk": "Medium"},
    "stomach pain": {"condition": "Gastritis / Digestive Issue", "specialization": "Gastroenterologist", "risk": "Medium"},
    "vomiting": {"condition": "Food Poisoning / Gastric Issue", "specialization": "Gastroenterologist", "risk": "Medium"},
    "skin rash": {"condition": "Skin Allergy / Irritation", "specialization": "Dermatologist", "risk": "Low"},
    "back pain": {"condition": "Muscle Strain / Orthopedic Issue", "specialization": "Orthopedic", "risk": "Low"},
    "joint pain": {"condition": "Arthritis / Joint Inflammation", "specialization": "Orthopedic", "risk": "Medium"},
    "sore throat": {"condition": "Throat Infection", "specialization": "ENT Specialist", "risk": "Low"},
    "blurred vision": {"condition": "Eye Strain / Eye Condition", "specialization": "Ophthalmologist", "risk": "Medium"},
    "weight loss": {"condition": "Metabolic / Hormonal Change", "specialization": "Endocrinologist", "risk": "Medium"},
}

EMERGENCY_TRIGGERS = {"chest pain", "shortness of breath", "fainting", "severe bleeding", "unconscious"}


def analyze_symptoms(symptom_text, duration, severity):
    parts = [s.strip().lower() for s in symptom_text.split(",") if s.strip()]
    matched = []
    specializations = []
    score = 0

    for part in parts:
        if part in SYMPTOM_RULES:
            rule = SYMPTOM_RULES[part]
            matched.append(rule["condition"])
            specializations.append(rule["specialization"])
            score += {"Low": 1, "Medium": 2, "High": 4}[rule["risk"]]

    if severity == "High":
        score += 3
    elif severity == "Medium":
        score += 2
    else:
        score += 1

    if duration in ["More than 3 days", "1 week or more"]:
        score += 2

    emergency = any(sym in EMERGENCY_TRIGGERS for sym in parts)
    if emergency:
        risk = "Emergency"
    elif score >= 7:
        risk = "High"
    elif score >= 4:
        risk = "Medium"
    else:
        risk = "Low"

    condition = matched[0] if matched else "General health concern - clinical consultation recommended"
    specialization = specializations[0] if specializations else "General Physician"
    return {
        "symptom_list": parts,
        "condition": condition,
        "specialization": specialization,
        "risk": risk,
        "emergency": emergency,
    }


# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        phone = request.form.get("phone", "").strip()
        age = request.form.get("age", "").strip()
        gender = request.form.get("gender", "").strip()
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for("register"))

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE email = ?", (email,))
        existing_user = cur.fetchone()

        if existing_user:
            conn.close()
            flash("Email already registered. Please login.", "warning")
            return redirect(url_for("login"))

        password_hash = generate_password_hash(password)
        cur.execute(
            """
            INSERT INTO users (name, email, phone, age, gender, password_hash)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (name, email, phone, age if age else None, gender, password_hash),
        )
        conn.commit()
        conn.close()

        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            flash("Login successful.", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) AS total FROM appointments WHERE user_id = ?", (session["user_id"],))
    appointment_count = cur.fetchone()["total"]

    cur.execute("SELECT COUNT(*) AS total FROM symptom_logs WHERE user_id = ?", (session["user_id"],))
    symptom_count = cur.fetchone()["total"]

    cur.execute(
        """
        SELECT a.*, d.name AS doctor_name, d.specialization, d.hospital
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.user_id = ?
        ORDER BY a.id DESC LIMIT 3
        """,
        (session["user_id"],),
    )
    recent_appointments = cur.fetchall()

    cur.execute(
        "SELECT COUNT(*) AS total FROM payments p JOIN appointments a ON p.appointment_id = a.id WHERE a.user_id = ? AND p.payment_status = 'Paid'",
        (session["user_id"],),
    )
    paid_count = cur.fetchone()["total"]

    cur.execute("SELECT * FROM doctors ORDER BY experience DESC LIMIT 4")
    top_doctors = cur.fetchall()
    conn.close()

    return render_template(
        "dashboard.html",
        appointment_count=appointment_count,
        symptom_count=symptom_count,
        paid_count=paid_count,
        recent_appointments=recent_appointments,
        top_doctors=top_doctors,
    )


@app.route("/symptom_checker", methods=["GET", "POST"])
@login_required
def symptom_checker():
    result = None
    doctors = []

    if request.method == "POST":
        symptoms = request.form["symptoms"].strip()
        duration = request.form["duration"]
        severity = request.form["severity"]

        result = analyze_symptoms(symptoms, duration, severity)

        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO symptom_logs (user_id, symptoms, duration, severity, predicted_condition, recommended_specialization, risk_level)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session["user_id"],
                symptoms,
                duration,
                severity,
                result["condition"],
                result["specialization"],
                result["risk"],
            ),
        )
        cur.execute(
            "SELECT * FROM doctors WHERE specialization = ? ORDER BY experience DESC",
            (result["specialization"],),
        )
        doctors = cur.fetchall()
        conn.commit()
        conn.close()

    return render_template("symptom_checker.html", result=result, doctors=doctors)


@app.route("/appointment", methods=["GET", "POST"])
@login_required
def appointment():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM doctors ORDER BY specialization, name")
    doctors = cur.fetchall()

    if request.method == "POST":
        doctor_id = request.form["doctor_id"]
        symptoms = request.form["symptoms"].strip()
        appointment_date = request.form["appointment_date"]
        appointment_time = request.form["appointment_time"]

        booking_code = f"APPT{random.randint(10000, 99999)}"
        cur.execute(
            """
            INSERT INTO appointments (user_id, doctor_id, symptoms, appointment_date, appointment_time, booking_code)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (session["user_id"], doctor_id, symptoms, appointment_date, appointment_time, booking_code),
        )
        appointment_id = cur.lastrowid

        cur.execute("SELECT fee FROM doctors WHERE id = ?", (doctor_id,))
        fee = cur.fetchone()["fee"]
        cur.execute(
            "INSERT INTO payments (appointment_id, amount, payment_status) VALUES (?, ?, 'Pending')",
            (appointment_id, fee),
        )
        conn.commit()
        conn.close()

        flash("Appointment booked successfully. Please complete payment.", "success")
        return redirect(url_for("payment", appointment_id=appointment_id))

    conn.close()
    return render_template("appointment.html", doctors=doctors)


@app.route("/payment/<int:appointment_id>", methods=["GET", "POST"])
@login_required
def payment(appointment_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT a.id, a.booking_code, a.appointment_date, a.appointment_time,
               d.name AS doctor_name, d.specialization, d.hospital,
               p.amount, p.payment_status
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN payments p ON p.appointment_id = a.id
        WHERE a.id = ? AND a.user_id = ?
        """,
        (appointment_id, session["user_id"]),
    )
    data = cur.fetchone()

    if not data:
        conn.close()
        flash("Appointment not found.", "danger")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        transaction_id = f"TXN{random.randint(100000, 999999)}"
        cur.execute(
            """
            UPDATE payments
            SET payment_status = 'Paid', transaction_id = ?, payment_date = ?
            WHERE appointment_id = ?
            """,
            (transaction_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), appointment_id),
        )
        conn.commit()
        conn.close()
        flash("Payment completed successfully.", "success")
        return redirect(url_for("success", appointment_id=appointment_id))

    conn.close()
    return render_template("payment.html", data=data)


@app.route("/success/<int:appointment_id>")
@login_required
def success(appointment_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT a.booking_code, a.appointment_date, a.appointment_time,
               d.name AS doctor_name, d.specialization, d.hospital,
               p.amount, p.transaction_id, p.payment_date, p.payment_status
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN payments p ON p.appointment_id = a.id
        WHERE a.id = ? AND a.user_id = ?
        """,
        (appointment_id, session["user_id"]),
    )
    receipt = cur.fetchone()
    conn.close()

    if not receipt:
        flash("Receipt not found.", "danger")
        return redirect(url_for("dashboard"))

    return render_template("success.html", receipt=receipt)


@app.route("/history")
@login_required
def history():
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT a.booking_code, a.appointment_date, a.appointment_time, a.status,
               d.name AS doctor_name, d.specialization, p.amount, p.payment_status
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        LEFT JOIN payments p ON p.appointment_id = a.id
        WHERE a.user_id = ?
        ORDER BY a.id DESC
        """,
        (session["user_id"],),
    )
    appointments = cur.fetchall()

    cur.execute(
        """
        SELECT symptoms, duration, severity, predicted_condition, recommended_specialization, risk_level, created_at
        FROM symptom_logs
        WHERE user_id = ?
        ORDER BY id DESC
        """,
        (session["user_id"],),
    )
    symptom_logs = cur.fetchall()
    conn.close()

    return render_template("history.html", appointments=appointments, symptom_logs=symptom_logs)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
