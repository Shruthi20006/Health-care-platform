from app import init_db

if __name__ == "__main__":
    init_db()
    print("Advanced healthcare database created successfully.")
